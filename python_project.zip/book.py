class Book:
    def __init__(self, title, author, category, price, rate, pages, characters, image):
        self.title = title
        self.author = author
        self.category = category
        self.price = price
        self.rate = rate
        self.pages = pages
        self.characters = characters
        self.image = image
